from setuptools import setup

setup(
	name='goto',
	py_modules=['goto'],
	author='Sebastian Noack <sebastian.noack@gmail.com>'
)
